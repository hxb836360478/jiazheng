function myDate(date){
    var date = new Date(date);
    var month = date.getMonth()+1;
    month = month<10?'0'+month:month;
    var day = date.getDate();
    day = day<10?'0'+day:day;
    var hours = date.getHours();
    hours = hours<10?'0'+hours:hours;
    var minutes= date.getMinutes();
    minutes= minutes<10?'0'+minutes:minutes;
    var seconds = date.getSeconds();
    seconds = seconds<10?'0'+seconds:seconds;	
    var str = date.getFullYear()+'-'+month+'-'+day+' '+hours+':'+minutes+':'+seconds;
    return str
}